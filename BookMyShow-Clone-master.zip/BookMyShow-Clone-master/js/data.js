let movies = [
    {
        image: 'img/banner/banner1.webp'
    },
    {
        image: 'img/banner/banner2.webp'
    },
    {
        image: 'img/banner/banner3.webp'
    },
    {
        image: 'img/banner/banner4.webp'
    },
    {
        image: 'img/banner/banner5.webp'
    },
    {
        image: 'img/banner/banner6.webp'
    }
]